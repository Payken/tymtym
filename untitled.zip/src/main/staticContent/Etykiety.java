package main.staticContent;

/**
 * Created by fdarmoch on 2016-04-16.
 */
public class Etykiety {
    private  static Etykiety instance =null;
    private static String wprowadzWartosc;
    private static String nazwaZbioru;
    private static String srednia;
    private static String mediana;
    private static String korelacja;

    protected Etykiety(){};
    public static Etykiety getInstance(){
        if(instance==null){
            instance=new Etykiety();
            wprowadzWartosc="Wprowadz Wartosc";
            nazwaZbioru="Nazwa Zbioru";
            srednia="Srednia";
            mediana="Mediana";
            korelacja="Korelacja";
        }
        return instance;
    }

    public static String getWprowadzWartosc() {
        return wprowadzWartosc;
    }

    public static void setWprowadzWartosc(String wprowadzWartosc) {
        Etykiety.wprowadzWartosc = wprowadzWartosc;
    Logger.getInstance().info("zmieniono etykiete Wprowadz Wartosc na: "+wprowadzWartosc);
    }

    public static String getNazwaZbioru() {
        return nazwaZbioru;
    }

    public static void setNazwaZbioru(String nazwaZbioru) {
        Etykiety.nazwaZbioru = nazwaZbioru;
        Logger.getInstance().info("zmieniono etykiete Nazwa Zbioru na: "+nazwaZbioru);
    }

    public static String getSrednia() {
        return srednia;
    }

    public static void setSrednia(String srednia) {
        Etykiety.srednia = srednia;
        Logger.getInstance().info("zmieniono etykiete Srednia na: "+srednia);
    }

    public static String getMediana() {
        return mediana;

    }

    public static void setMediana(String mediana) {
        Etykiety.mediana = mediana;
        Logger.getInstance().info("zmieniono etykiete Mediana na: "+mediana);
    }

    public static String getKorelacja() {
        return korelacja;

    }


    public static void setKorelacja(String korelacja) {
        Etykiety.korelacja = korelacja;
        Logger.getInstance().info("zmieniono etykiete Korelacja na: "+korelacja);
    }
}
