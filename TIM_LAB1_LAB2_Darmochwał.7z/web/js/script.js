/**
 * Created by fdarmoch on 2016-04-21.
 */
// script.js

// create the module and name it scotchApp
var scotchApp = angular.module('scotchApp', []);

// create the controller and inject Angular's $scope
scotchApp.controller('mainController', function($scope) {

    // create a message to display in our view
    $scope.message = 'Everyone come and see how good I look!';
});

// script.js

// create the module and name it scotchApp
// also include ngRoute for all our routing needs
var scotchApp = angular.module('scotchApp', ['ngRoute']);

// configure our routes
scotchApp.config(function($routeProvider) {
    $routeProvider


        .when('/', {
            templateUrl : 'pages/home.html',
            controller  : 'mainController'
        })


        .when('/add', {
            templateUrl : 'pages/add.html',
            controller  : 'addController'
        })

        .when('/del', {
            templateUrl : 'pages/del.html',
            controller  : 'delController'
        })


        .when('/labels', {
            templateUrl : 'pages/labels.html',
            controller  : 'labelsController'
        })


        .when('/parameters', {
            templateUrl : 'pages/parameters.html',
            controller  : 'parametersController'
        })
    .when('/stats', {
        templateUrl : 'pages/stats.html',
        controller  : 'statsController'
    })
    .when('/addvalue', {
        templateUrl : 'pages/addvalue.html',
        controller  : 'addvalueController'
    });
});

// create the controller and inject Angular's $scope
scotchApp.controller('mainController', function($scope) {
    // create a message to display in our view
    $scope.message = 'Everyone come and see how good I look!';
});

scotchApp.controller('addController', function($scope,$http) {
    $scope.processForm = function() {
        $http.get('add').then( function (response) {
            $scope.params = response.data;
            console.log(response.data);
        });
    };

});

scotchApp.controller('contactController', function($scope) {
    $scope.message = '.';
});