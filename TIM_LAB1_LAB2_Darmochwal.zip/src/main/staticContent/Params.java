package main.staticContent;

/**
 * Created by fdarmoch on 2016-04-19.
 */
public class Params {

    private static Params instance = null;
    private static String logFileFormat;
    private static boolean correlationIsTurnOn;
    private static String className;
    private static String labels;
    protected Params() {
    }


    public static Params getInstance() {
        if (instance == null) {
            instance = new Params();
            logFileFormat = "csv";
            className="A";
            labels="C";
                  }
        return instance;
    }



    public static String setBootstrapIsTurnOn(boolean bootstrapIsTurnOn) {

        if(bootstrapIsTurnOn)
        return "<div class=\"alert alert-success\" role=\"alert\"> Wlaczono Bootstrap </div>";
        else
        return "<div class=\"alert alert-success\" role=\"alert\"> Wylaczono Bootstrap</div>";
    }

    public static String getLogFileFormat() {
        return logFileFormat;
    }

    public static void setLogFileFormat(String logFileFormat) {
        Params.logFileFormat = logFileFormat;
        Logger.getInstance().info("Zmieniono format pliku na: "+logFileFormat);
    }



    public static boolean isCorrelationIsTurnOn() {
        return correlationIsTurnOn;
    }

    public static void setCorrelationIsTurnOn(boolean correlationIsTurnOn) {
        Params.correlationIsTurnOn = correlationIsTurnOn;
    }

    public static String getClassName() {
        return className;
    }

    public static void setClassName(String className) {
        Params.className = className;
    }

    public static String getLabels() {
        return labels;
    }

    public static void setLabels(String labels) {
        Params.labels = labels;
    }
}
